<?php

namespace App;

use Jenssegers\Mongodb\Eloquent\Model as Eloquent;

class Rooms extends Eloquent
{
    public $table = "rooms";
}
