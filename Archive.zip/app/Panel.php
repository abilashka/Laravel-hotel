<?php

namespace App;

use Jenssegers\Mongodb\Eloquent\Model as Eloquent;

class Panel extends Eloquent
{
    //
}
