<?php

namespace App;

use Jenssegers\Mongodb\Eloquent\Model as Eloquent;

class Booking extends Eloquent
{
    public $table = "Booking";
}
