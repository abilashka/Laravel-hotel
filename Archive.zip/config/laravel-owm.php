<?php

return [
    'api_key' => '',            // visit: http://openweathermap.org/appid#get for more info.
    'routes_enabled' => true,   // If the routes have to be enabled.
];
