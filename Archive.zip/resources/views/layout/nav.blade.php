<header>
  <!-- Navigation -->
  <div class="navbar yamm navbar-default" id="sticky">
    <div class="container">
      <div class="navbar-header">
        <button type="button" data-toggle="collapse" data-target="#navbar-collapse-grid" class="navbar-toggle"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <a href="/index.php" class="navbar-brand">
        <!-- Logo -->
        <div id="logo"> <img id="default-logo" src="/images/logo.png" alt="Starhotel" style="height:44px;"> <img id="retina-logo" src="/images/logo-retina.png" alt="Starhotel" style="height:44px;"> </div>
        </a> </div>
      <div id="navbar-collapse-grid" class="navbar-collapse collapse">
        <ul class="nav navbar-nav">
          <li class="dropdown"> <a href="/">Home</a>
          </li>
          <li> <a href="/rooms">Room List</a></li>
          <li> <a href="/gallery">Gallery</a></li>
          <li> <a href="/contact">Contact</a></li>
        </ul>
      </div>
    </div>
  </div>

</header>